#!/usr/bin/env bash

set -e

# NOTE: this tag is NOT used
TAG="8.3.411"

# NOTE: need to disable compiler checks to compile
CFLAGS="-Wno-discarded-qualifiers -Wno-incompatible-pointer-types"
CFLAGS="${CFLAGS} -Wno-write-strings -Wno-error"

mkdir -p /builddir
cd       /builddir

git clone https://github.com/RTimothyEdwards/magic
cd magic

#git checkout "${TAG}"

# NOTE: dependency of some old script
apt-get install -y csh

# NOTE: does not compile :(
sed -i -e 's/-Werror=implicit-function-declaration//g' scripts/configure

./configure CFLAGS="${CFLAGS}"

make

make install

