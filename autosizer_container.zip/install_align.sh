#!/usr/bin/env bash

set -e

# Source: https://github.com/ALIGN-analoglayout/ALIGN-public/blob/master/docker/dockerfile

mkdir -p /builddir/align
cd       /builddir/align

git clone https://github.com/ALIGN-analoglayout/ALIGN-public.git
cd /builddir/align/ALIGN-public

apt-get install -y \
    python3-setuptools python3-wheel python3-pybind11 python3-pybind11 \
    cmake ninja-build python3-networkx python3-gdspy python3-yaml \
    z3 python3-more-itertools python3-colorlog python3-plotly \
    python3-numpy python3-pandas python3-pytest \
    python3-pytest-cov python3-pytest-xdist python3-pytest-timeout \
    libffi-dev libboost-all-dev

pip install --break-system-packages \
    scikit-build 'pydantic>=1.9.2,<=1.20' mip dash memory_profiler flatdict \
    pytest-rerunfailures pytest-cpp


env CMAKE_POLICY_VERSION_MINIMUM=3.5 BUILD_TYPE='Release' \
    pip install -v . --break-system-packages

cat >/usr/local/bin/run_align <<'EOF'
#!/usr/bin/env bash

die ()
{
    echo "ERROR: ${*}"
    exit 1
}


[[ -n "${ALIGN_PDK_DIR}" ]] || die "Variable ALIGN_PDK_DIR is not set"
[[ -d "${ALIGN_PDK_DIR}" ]] \
    || die "Directory '${ALIGN_PDK_DIR}' does not exist"
[[ -n "${ALIGN_CKT_DIR}" ]] || die "Variable ALIGN_CKT_DIR is not set"
[[ -d "${ALIGN_CKT_DIR}" ]] \
    || die "Directory '${ALIGN_CKT_DIR}' does not exist"

echo "PDK directory : ${ALIGN_PDK_DIR}"
echo "Netlist directory : ${ALIGN_CKT_DIR}"

export OPENBLAS_NUM_THREADS=1
exec schematic2layout.py -p "${ALIGN_PDK_DIR}" "${ALIGN_CKT_DIR}"
EOF

chmod +x /usr/local/bin/run_align
rm -rf /builddir/align/ALIGN-public/_skbuild

